/*
 * =====================================================================
 *  ACIONAMENTO DOS MOTORES
 * =====================================================================
 *  Traduz as variaveis de velocidade (velocL / velocR) em sinais PWM
 *  para a ponte H de cada motor.
 * =====================================================================
 */

// Envia os valores de velocL/velocR (podem ser negativos) para os motores
void acionarMotores() {
  // Motor esquerdo (M2): sinal negativo inverte o sentido de giro
  if (velocL >= 0) {
    ledcWrite(M2_A, 0);
    ledcWrite(M2_B, velocL);
  } else {
    ledcWrite(M2_A, abs(velocL));
    ledcWrite(M2_B, 0);
  }

  // Motor direito (M1): sinal negativo inverte o sentido de giro
  if (velocR >= 0) {
    ledcWrite(M1_A, 0);
    ledcWrite(M1_B, velocR);
  } else {
    ledcWrite(M1_A, abs(velocR));
    ledcWrite(M1_B, 0);
  }
}

// Freia os dois motores (curto-circuito nas duas pontes H)
void pararMotores() {
  ledcWrite(M1_A, 4095);
  ledcWrite(M1_B, 4095);
  ledcWrite(M2_A, 4095);
  ledcWrite(M2_B, 4095);
}
