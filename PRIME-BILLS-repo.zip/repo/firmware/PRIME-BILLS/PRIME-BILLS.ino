/*
 * =====================================================================
 *  PRIME-BILLS - Firmware do Micromouse (ESP32)
 * =====================================================================
 *  Robo resolvedor de labirinto com:
 *    - Giroscopio MPU6050 para controle de giros
 *    - Encoders (roda esquerda/direita) para controle de distancia
 *    - 4 sensores IR para deteccao de paredes
 *    - Algoritmo de flood-fill para navegacao do labirinto
 *    - Display OLED SSD1306 (opcional, para debug/status)
 *
 *  Estrutura do sketch (abas):
 *    PRIME-BILLS.ino   -> setup(), loop(), pinos e constantes globais
 *    acionarmotores.ino-> aciona e para os motores (PWM)
 *    andarcelula.ino   -> anda uma celula do labirinto em linha reta
 *    girar.ino         -> gira o robo em um angulo alvo (PID de giro)
 *    pidencoder.ino    -> PID de alinhamento usando os encoders
 *    atualizaang.ino   -> integra o giroscopio para saber o angulo atual
 *    calibrampu.ino    -> calibra o offset do giroscopio (robo parado)
 *    sensores.ino      -> leitura bruta dos sensores IR
 *    labirinto.ino     -> mapa, flood-fill e logica de navegacao
 * =====================================================================
 */

#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_GFX.h>
#include <ESP32Encoder.h>

// -----------------------------------------------------------------
// ENCODERS
// -----------------------------------------------------------------
ESP32Encoder encLeft;
ESP32Encoder encRight;

// -----------------------------------------------------------------
// GIROSCOPIO / IMU
// -----------------------------------------------------------------
Adafruit_MPU6050 mpu;

float anguloAtual = 0.0;           // Angulo atual integrado (graus)
unsigned long ultimoTempoPID = 0;
unsigned long tempoAnteriorMPU = 0;
float offsetGiroZ = 0.0;           // Offset de calibracao do eixo Z

#define esquerda 90                // Angulo relativo para virar a esquerda
#define direita -90                // Angulo relativo para virar a direita

bool giroflag = false;             // Sinaliza que um giro acabou de ser feito

// -----------------------------------------------------------------
// DISPLAY OLED
// -----------------------------------------------------------------
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
unsigned long lastDisplayUpdate = 0;

// -----------------------------------------------------------------
// BOTAO E LEDS
// -----------------------------------------------------------------
const int botao = 36;
const int led   = 38;
const int led2  = 37;

// -----------------------------------------------------------------
// PINOS DOS MOTORES (ponte H, 1 pino por sentido de giro)
// -----------------------------------------------------------------
const int M2_A = 6;   // Motor esquerdo - sentido A
const int M2_B = 7;   // Motor esquerdo - sentido B
const int M1_A = 15;  // Motor direito  - sentido A
const int M1_B = 16;  // Motor direito  - sentido B

// -----------------------------------------------------------------
// SENSORES DE PAREDE (IR analogicos)
// -----------------------------------------------------------------
#define sld 2   // Sensor lateral direito
#define sfd 18  // Sensor frontal direito
#define sfe 3   // Sensor frontal esquerdo
#define sle 10  // Sensor lateral esquerdo

int leituraSLE = 0;
int leituraSFE = 0;
int leituraSFD = 0;
int leituraSLD = 0;
int minVal[4], maxVal[4];

const int LIMIAR_PAREDE_PERTO = 500; // Acima disso, considera que ha parede perto

// -----------------------------------------------------------------
// PID DE GIRO (usado dentro de girar.ino)
// -----------------------------------------------------------------
float Kd = 1;
float Kp = 1;
float erroAnterior = 0;

// -----------------------------------------------------------------
// ODOMETRIA / DISTANCIA PERCORRIDA
// -----------------------------------------------------------------
const float PULSES_PER_REV = 14;
const float GEAR_RATIO = 20.0;
const float WHEEL_DIAMETER_CM = 2.2;
const float DIST_PER_PULSE_CM = (PI * WHEEL_DIAMETER_CM) / (PULSES_PER_REV * GEAR_RATIO);

float alvo = 18.0;       // Distancia alvo do movimento atual (cm)
float distancia = 0;     // Distancia ja percorrida no movimento atual (cm)
int velocMax = 1100;     // Limite maximo de PWM
int velocR = 0, velocL = 0;

// -----------------------------------------------------------------
// PID DE ALINHAMENTO (mantem o robo andando reto, usa os encoders)
// -----------------------------------------------------------------
float Kpm = 8.0, Kim = 1.5, Kdm = 0.0;
float error = 0, lastError = 0, integral = 0;
unsigned long lastTimePID = 0;

float Kp_dist = 65.0; // Converte erro de distancia (cm) em PWM

// -----------------------------------------------------------------
// MAPA DO LABIRINTO (flood-fill)
// -----------------------------------------------------------------
#define TAM8
#ifdef TAM16
#define TAM 16
#endif
#ifdef TAM8
#define TAM 8
#endif

#define NORTE 0
#define LESTE 1
#define SUL   2
#define OESTE 3

int x = 0;
int y = 0;
int direcao = NORTE;
int countbeco = 0;
int mapa[TAM][TAM];

bool paredeFrente = false;
bool paredeDireita = false;
bool paredeEsquerda = false;

bool movimentoInicialFeito = false;

// =====================================================================
// SETUP
// =====================================================================
void setup() {
  Serial.begin(115200);
  Wire.begin(8, 9);

  // Configura os encoders com pull-up interno
  ESP32Encoder::useInternalWeakPullResistors = puType::up;
  encLeft.attachHalfQuad(5, 4);
  encRight.attachHalfQuad(1, 11);
  encLeft.clearCount();
  encRight.clearCount();

  // Inicializa o display OLED
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();
  display.setTextColor(WHITE);
  display.println("Iniciando...");
  display.display();

  // Configura os canais PWM dos motores (980 Hz, 12 bits)
  ledcAttach(M1_A, 980, 12);
  ledcAttach(M1_B, 980, 12);
  ledcAttach(M2_A, 980, 12);
  ledcAttach(M2_B, 980, 12);

  pinMode(led, OUTPUT);
  pinMode(led2, OUTPUT);
  pinMode(botao, INPUT);

  // Inicializa o MPU6050
  if (!mpu.begin()) {
    Serial.println("Falha ao encontrar o MPU6050");
    while (1) { delay(10); }
  }
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

  delay(100);
  calibrarMPU();                 // Robo deve estar parado nesse momento
  tempoAnteriorMPU = millis();

  inicializaMapa();              // Gera o mapa de distancias ate o centro

  delay(1000);
}

// =====================================================================
// LOOP PRINCIPAL
// =====================================================================
void loop() {

  // Primeiro movimento: sai da celula inicial ate o centro dela
  if (!movimentoInicialFeito) {
    alvo = 2.7;
    andarCelula();
    delay(50);
    movimentoInicialFeito = true;
    return;
  }

  // Chegou ao centro do labirinto: encerra a execucao
  if (noCentro()) {
    Serial.println("Cheguei ao centro!");
    pararMotores();
    digitalWrite(led2, 1);
    while (1); // Trava o programa aqui
  }

  // Le os sensores fisicos e atualiza quais paredes existem ao redor
  lerParedes();

  // Consulta o mapa de flood-fill nas 3 direcoes possiveis
  int frente = paredeFrente  ? 999 : valorFrente();
  int dirMap = paredeDireita ? 999 : valorDireita();
  int esqMap = paredeEsquerda ? 999 : valorEsquerda();

  // Segue sempre para a celula vizinha com o menor valor no mapa
  if (frente <= dirMap && frente <= esqMap) {
    andaFrente();
  } else if (dirMap < esqMap) {
    viraDireita();
    andaFrente();
  } else {
    viraEsquerda();
    andaFrente();
  }
}
