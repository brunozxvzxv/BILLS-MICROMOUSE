/*
 * =====================================================================
 *  MOVIMENTO EM LINHA RETA (ANDAR UMA CELULA)
 * =====================================================================
 */

// Zera odometria e temporizadores antes de iniciar um novo movimento
void iniciarMovimento() {
  encLeft.clearCount();
  encRight.clearCount();
  distancia = 0;
  lastError = 0;
  integral = 0;
  lastTimePID = micros(); // Reseta o tempo do PID de alinhamento
}

// Calcula a distancia percorrida com base na media dos dois encoders
void atualizarDistancia() {
  distancia = ((abs(encLeft.getCount()) + abs(encRight.getCount())) / 2.0) * DIST_PER_PULSE_CM;
}

// Anda em linha reta ate percorrer a distancia definida em "alvo",
// mantendo o robo alinhado com o PID de encoders e parando se detectar
// parede muito perto pelos sensores frontais
void andarCelula() {
  iniciarMovimento();
  atualizarDistancia();

  // Forca minima de PWM para o motor conseguir girar devagar sem travar
  // (ajustar entre 350 e 600 dependendo da bateria)
  int pwmMinimo = 600;

  if (giroflag) {
    alvo = alvo - 1.5;
  } else if (!movimentoInicialFeito) {
    alvo = 3.0;
  } else {
    alvo = 17.5;
  }

  while (true) {
    atualizarDistancia();
    lerSensores();

    float erroDistancia = alvo - distancia;

    // Para se chegou perto o suficiente do alvo OU se ha parede muito perto na frente
    if (abs(erroDistancia) < 0.5 || leituraSFE > 2500 || leituraSFD > 2500) {
      pararMotores();
      break;
    }

    // Velocidade proporcional ao erro de distancia
    int vBase = (int)(erroDistancia * Kp_dist);

    // Garante um minimo de forca para vencer o atrito do motor
    if (vBase > 0 && vBase < pwmMinimo) {
      vBase = pwmMinimo;
    } else if (vBase < 0 && vBase > -pwmMinimo) {
      vBase = -pwmMinimo;
    }

    // Limita na velocidade maxima permitida
    vBase = constrain(vBase, -velocMax, velocMax);

    // Corrige as velocidades das duas rodas para manter o robo reto
    pidAlinhamento(vBase);

    acionarMotores();
  }

  giroflag = false;
}
