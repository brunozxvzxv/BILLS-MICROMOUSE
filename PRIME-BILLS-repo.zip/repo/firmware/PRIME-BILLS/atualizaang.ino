/*
 * =====================================================================
 *  ATUALIZACAO DO ANGULO (INTEGRACAO DO GIROSCOPIO)
 * =====================================================================
 */

// Le o giroscopio e integra a velocidade angular no tempo para obter
// o angulo atual do robo em graus (eixo Z)
void atualizarAngulo() {
  sensors_event_t a, g, temp;
  mpu.getEvent(&a, &g, &temp);

  unsigned long tempoAtual = millis();
  float dt = (tempoAtual - tempoAnteriorMPU) / 1000.0; // Delta de tempo em segundos
  tempoAnteriorMPU = tempoAtual;

  // Remove o offset de calibracao e converte de rad/s para graus/s
  float velocidadeAngularZ = (g.gyro.z - offsetGiroZ) * 57.2958;

  // Ignora ruido muito pequeno para evitar deriva (drift) parado
  if (abs(velocidadeAngularZ) > 0.1) {
    anguloAtual += velocidadeAngularZ * dt;
  }
}
