/*
 * =====================================================================
 *  CALIBRACAO DO GIROSCOPIO (MPU6050)
 * =====================================================================
 *  O robo deve ficar parado durante essa rotina. Ela calcula a media
 *  das leituras do eixo Z parado, que representa o "ruido de zero"
 *  (offset) do sensor, usado depois para corrigir todas as leituras.
 * =====================================================================
 */

void calibrarMPU() {
  float somaZ = 0;
  int amostras = 250;

  for (int i = 0; i < amostras; i++) {
    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);
    somaZ += g.gyro.z;
    delay(10);
  }

  offsetGiroZ = somaZ / amostras;
}
