/*
 * =====================================================================
 *  LABIRINTO: MAPA (FLOOD-FILL) E NAVEGACAO
 * =====================================================================
 *  O mapa guarda, para cada celula, a distancia (em numero de celulas)
 *  ate o centro do labirinto. O robo sempre segue para a celula
 *  acessivel com o menor valor, o que garante que ele caminha na
 *  direcao do centro.
 * =====================================================================
 */

// Preenche o mapa com a distancia (Manhattan) ate o centro do labirinto
void inicializaMapa() {
  for (int i = 0; i < TAM; i++) {
    for (int j = 0; j < TAM; j++) {
#ifdef TAM16
      mapa[i][j] = min(
          min(abs(i - 7) + abs(j - 7), abs(i - 7) + abs(j - 8)),
          min(abs(i - 8) + abs(j - 7), abs(i - 8) + abs(j - 8))
      );
#endif
#ifdef TAM8
      // Distancia ate o quadrado central 2x2 de um mapa 8x8
      mapa[i][j] = min(
          min(abs(i - 3) + abs(j - 3), abs(i - 3) + abs(j - 4)),
          min(abs(i - 4) + abs(j - 3), abs(i - 3) + abs(j - 4))
      );
#endif
    }
  }
}

// Verifica se o robo ja esta em alguma das celulas centrais
bool noCentro() {
#ifdef TAM16
  return ((x == 7 || x == 8) && (y == 7 || y == 8));
#endif
#ifdef TAM8
  return ((x == 3 || x == 4) && (y == 3 || y == 4));
#endif
}

// Valor do mapa na celula imediatamente a frente da direcao atual
int valorFrente() {
  if (direcao == NORTE && y + 1 < TAM) return mapa[x][y + 1];
  if (direcao == LESTE && x + 1 < TAM) return mapa[x + 1][y];
  if (direcao == SUL   && y - 1 >= 0) return mapa[x][y - 1];
  if (direcao == OESTE && x - 1 >= 0) return mapa[x - 1][y];
  return 999; // Fora dos limites do mapa
}

// Valor do mapa na celula a direita da direcao atual
int valorDireita() {
  if (direcao == NORTE && x + 1 < TAM) return mapa[x + 1][y];
  if (direcao == LESTE && y - 1 >= 0) return mapa[x][y - 1];
  if (direcao == SUL   && x - 1 >= 0) return mapa[x - 1][y];
  if (direcao == OESTE && y + 1 < TAM) return mapa[x][y + 1];
  return 999;
}

// Valor do mapa na celula a esquerda da direcao atual
int valorEsquerda() {
  if (direcao == NORTE && x - 1 >= 0) return mapa[x - 1][y];
  if (direcao == LESTE && y + 1 < TAM) return mapa[x][y + 1];
  if (direcao == SUL   && x + 1 < TAM) return mapa[x + 1][y];
  if (direcao == OESTE && y - 1 >= 0) return mapa[x][y - 1];
  return 999;
}

// Le os sensores fisicos e atualiza quais paredes existem ao redor do robo
void lerParedes() {
  lerSensores();
  paredeFrente = (leituraSFE > LIMIAR_PAREDE_PERTO || leituraSFD > LIMIAR_PAREDE_PERTO);
  paredeDireita = (leituraSLD > LIMIAR_PAREDE_PERTO);
  paredeEsquerda = (leituraSLE > LIMIAR_PAREDE_PERTO);
}

// Verifica se o robo esta cercado de paredes nas 3 direcoes possiveis
bool travado() {
  return paredeFrente && paredeEsquerda && paredeDireita;
}

// Anda uma celula na direcao atual e atualiza a posicao logica (x, y)
void andaFrente() {
  alvo = 17.5; // Distancia de uma celula (ajustar conforme o tamanho real)
  iniciarMovimento();
  andarCelula();
  pararMotores();
  delay(50);

  if (direcao == NORTE) y = min(y + 1, TAM - 1);
  else if (direcao == LESTE) x = min(x + 1, TAM - 1);
  else if (direcao == SUL) y = max(y - 1, 0);
  else if (direcao == OESTE) x = max(x - 1, 0);
}

// Vira 90 graus a direita e atualiza a direcao logica
void viraDireita() {
  iniciarMovimento();
  girar(direita);
  pararMotores();
  delay(50);
  direcao = (direcao + 1) % 4;
}

// Vira 90 graus a esquerda e atualiza a direcao logica
void viraEsquerda() {
  iniciarMovimento();
  girar(esquerda);
  pararMotores();
  delay(50);
  direcao = (direcao + 3) % 4;
}

// Meia volta (180 graus), usada em becos sem saida
void meiaVolta() {
  viraDireita();
  viraDireita();
}
