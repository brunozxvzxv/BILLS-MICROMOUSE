/*
 * =====================================================================
 *  GIRO EM TORNO DO PROPRIO EIXO (PID DE ANGULO)
 * =====================================================================
 */

// Gira o robo por "anguloAlvo" graus relativos ao angulo atual,
// usando um PD sobre o angulo medido pelo giroscopio
void girar(float anguloAlvo) {

  // Usa um alvo relativo em vez de zerar anguloAtual, para nao
  // dessincronizar a integracao do giroscopio
  atualizarAngulo();
  float anguloInicial = anguloAtual;
  float anguloDestino = anguloInicial + anguloAlvo;

  float erro = anguloDestino - anguloAtual;
  float erroAnterior = erro;

  unsigned long ultimoTempo = millis();

  float kp_giro = 6.0;
  float kd_giro = 0.3;

  int pwmMinimo = 550;
  int velmax = 1500;

  while (abs(erro) > 1.3) {

    atualizarAngulo();

    unsigned long tempoAtual = millis();
    float dt = (tempoAtual - ultimoTempo) / 1000.0;
    if (dt <= 0.0 || dt > 0.5) dt = 0.01; // Protege contra dt invalido
    ultimoTempo = tempoAtual;

    erro = anguloDestino - anguloAtual;

    float P = erro * kp_giro;
    float taxaErro = (erro - erroAnterior) / dt;
    float D = taxaErro * kd_giro;
    erroAnterior = erro;

    float correcao = P + D;
    int pwm = abs(correcao);

    // Soma um PWM minimo para vencer a inercia, somente se houver correcao
    if (pwm > 0) {
      pwm += pwmMinimo;
    }
    pwm = constrain(pwm, 0, velmax);

    Serial.print("Angulo: "); Serial.print(anguloAtual);
    Serial.print(" Erro: "); Serial.print(erro);
    Serial.print(" Correcao: "); Serial.print(correcao);
    Serial.print(" PWM: "); Serial.println(pwm);

    // O sinal da correcao define o sentido do giro
    if (correcao < 0) {
      // Gira para a direita
      ledcWrite(M1_A, pwm);
      ledcWrite(M1_B, 0);
      ledcWrite(M2_A, 0);
      ledcWrite(M2_B, pwm);
    } else if (correcao > 0) {
      // Gira para a esquerda
      ledcWrite(M1_A, 0);
      ledcWrite(M1_B, pwm);
      ledcWrite(M2_A, pwm);
      ledcWrite(M2_B, 0);
    } else {
      // Freio ativo (short-brake) nas duas pontes H
      ledcWrite(M1_A, 4095);
      ledcWrite(M1_B, 4095);
      ledcWrite(M2_A, 4095);
      ledcWrite(M2_B, 4095);
    }

    delay(5);
  }

  pararMotores();
  Serial.println("Giro concluido!");
  giroflag = true;
}
