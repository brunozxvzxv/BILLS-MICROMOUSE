/*
 * =====================================================================
 *  PID DE ALINHAMENTO (BASEADO NOS ENCODERS)
 * =====================================================================
 */

// Recebe a velocidade base desejada e retorna, via velocL/velocR,
// as velocidades individuais corrigidas para manter o robo reto,
// comparando a contagem dos dois encoders
void pidAlinhamento(int vBase) {
  unsigned long now = micros();
  float dt = (now - lastTimePID) / 1000000.0;
  if (dt <= 0) dt = 0.001; // Protege contra dt invalido
  lastTimePID = now;

  // Erro = diferenca entre as contagens das duas rodas
  error = encLeft.getCount() - encRight.getCount();

  integral = constrain(integral, -500, 500);
  integral += error * dt;

  float derivative = (error - lastError) / dt;
  lastError = error;

  float correction = (Kpm * error) + (Kim * integral) + (Kdm * derivative);

  // Aplica a correcao em sentidos opostos em cada roda
  velocL = constrain(vBase - (int)correction, -4095, 4095);
  velocR = constrain(vBase + (int)correction, -4095, 4095);
}
