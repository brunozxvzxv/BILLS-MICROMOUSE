/*
 * =====================================================================
 *  LEITURA DOS SENSORES DE PAREDE (IR)
 * =====================================================================
 */

// Atualiza as leituras analogicas brutas dos 4 sensores de parede
void lerSensores() {
  leituraSFD = analogRead(sfd);
  leituraSFE = analogRead(sfe);
  leituraSLD = analogRead(sld);
  leituraSLE = analogRead(sle);
}
