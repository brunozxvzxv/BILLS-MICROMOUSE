# PRIME-BILLS

Firmware de um micromouse (robô resolvedor de labirinto) baseado em ESP32.

## Visão geral

O robô usa:

- **Giroscópio MPU6050** para controlar giros de 90°/180°
- **Encoders** nas duas rodas para medir distância percorrida e manter o robô alinhado
- **4 sensores IR** para detectar paredes (frente-esquerda, frente-direita, lateral-esquerda, lateral-direita)
- **Display OLED SSD1306** (opcional, para status/debug)
- Algoritmo de **flood-fill** para navegar até o centro do labirinto

## Estrutura do sketch

O Arduino IDE compila juntos todos os arquivos `.ino` dentro da mesma pasta. A pasta `firmware/PRIME-BILLS/` contém:

| Arquivo | Responsabilidade |
|---|---|
| `PRIME-BILLS.ino` | Includes, objetos de hardware, pinos/constantes globais, `setup()` e `loop()` |
| `acionarmotores.ino` | Aciona e freia os motores via PWM |
| `andarcelula.ino` | Anda em linha reta uma célula do labirinto |
| `girar.ino` | Gira o robô em um ângulo alvo (PID sobre o giroscópio) |
| `pidencoder.ino` | PID de alinhamento usando a diferença entre os encoders |
| `atualizaang.ino` | Integra o giroscópio para saber o ângulo atual |
| `calibrampu.ino` | Calibra o offset do giroscópio (robô parado) |
| `sensores.ino` | Leitura bruta dos sensores IR |
| `labirinto.ino` | Mapa, flood-fill e lógica de navegação |

## Hardware / pinos

| Sinal | Pino |
|---|---|
| Motor esquerdo (M2) | `M2_A = 6`, `M2_B = 7` |
| Motor direito (M1) | `M1_A = 15`, `M1_B = 16` |
| Encoder esquerdo | `5`, `4` |
| Encoder direito | `1`, `11` |
| I2C (MPU6050 / OLED) | SDA `8`, SCL `9` |
| Sensor lateral direito | `2` |
| Sensor frontal direito | `18` |
| Sensor frontal esquerdo | `3` |
| Sensor lateral esquerdo | `10` |
| Botão | `36` |
| LED 1 / LED 2 | `38` / `37` |

## Bibliotecas necessárias (Arduino IDE Library Manager)

- `Adafruit MPU6050`
- `Adafruit Unified Sensor`
- `Adafruit SSD1306`
- `Adafruit GFX Library`
- `ESP32Encoder`

## Como usar

1. Abra `firmware/PRIME-BILLS/PRIME-BILLS.ino` no Arduino IDE (todas as abas do mesmo diretório abrem juntas).
2. Instale as bibliotecas listadas acima.
3. Selecione a placa ESP32 correta em **Ferramentas > Placa**.
4. Compile e grave.
5. Mantenha o robô parado durante a calibração inicial do giroscópio (primeiros segundos após ligar).

## Licença

Ver [LICENSE](LICENSE).
